package javaapplication1;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.*;
import javax.swing.JOptionPane;

public class SendEmail {
    public static void sendEmail(String recipientEmail) {
        // my(admin) email credentials
        final String senderEmail = "saziyasadiq27@gmail.com"; 
        final String senderPassword = "xiossqqkdsxlolct"; //for my App Password 

        // SMTP properties
        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com"); // SMTP server
        properties.put("mail.smtp.port", "587"); // Port number
        properties.put("mail.smtp.auth", "true"); //for  Enable authentication
        properties.put("mail.smtp.starttls.enable", "true"); // for Secure connection

        // Session for authentication
        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(senderEmail, senderPassword);
            }
        });

        try {
            // Create message
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(senderEmail));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(recipientEmail));
            message.setSubject("Absent for today class");
            message.setText("Dear Student,\n" +
"\n" +
"Greetings from AbcInstitute\n" +
"\n" +
"I hope this email finds you well. I am writing to inform you that we have noticed your absence from our training institute. We understand that unexpected circumstances can arise, but it is important to attend classes regularly to ensure that you are receiving the best possible education.\n" +
"\n" +
"We encourage you to reach out to us and let us know if there are any issues or concerns that are preventing you from attending classes. Our faculty and staff are here to support you and help you overcome any challenges that you may be facing.\n" +
"\n" +
"If there is anything we can do to assist you, please do not hesitate to contact us. We want to work together to help you succeed in your educational journey.\n" +
"\n" +
"Thank you for your attention to this matter, and we look forward to seeing you back in class soon.\n" +
"\n" +
" \n" +
"\n" +
"Thanks & Regards,\n" +
"\n" +
"M. Nirmala,\n" +
"\n" +
"Batch Advisor,\n" +
"\n" +
"Ph: 73270 37327.\n" +
"\n" +
"www.abcinstitute.com");

            //for Sending email
            Transport.send(message);

            JOptionPane.showMessageDialog(null, "Email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Failed to send email: " + e.getMessage());
        }
    }
}
